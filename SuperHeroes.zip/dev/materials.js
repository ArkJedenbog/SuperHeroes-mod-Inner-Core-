




IDRegistry.genItemID("blackwool");
Item.createItem("blackwool", "Black wool", {name: "blackwool", meta: 0}, {stack: 64});


IDRegistry.genItemID("bluewool");
Item.createItem("bluewool", "Blue wool", {name: "bluewool", meta: 0}, {stack: 64});


IDRegistry.genItemID("darkbluewool");
Item.createItem("darkbluewool", "Dark blue wool", {name: "darkbluewool", meta: 0}, {stack: 64});


IDRegistry.genItemID("darkredwool");
Item.createItem("darkredwool", "Dark red wool", {name: "darkredwool", meta: 0}, {stack: 64});


IDRegistry.genItemID("darkvioletwool");
Item.createItem("darkvioletwool", "Dark violet wool", {name: "darkvioletwool", meta: 0}, {stack: 64});


IDRegistry.genItemID("orangewool");
Item.createItem("orangewool", "Orange wool", {name: "orangewool", meta: 0}, {stack: 64});


IDRegistry.genItemID("redwool");
Item.createItem("redwool", "Red wool", {name: "redwool", meta: 0}, {stack: 64});



IDRegistry.genItemID("violetwool");
Item.createItem("violetwool", "Violet wool", {name: "violetwool", meta: 0}, {stack: 64});


IDRegistry.genItemID("whitewool");
Item.createItem("whitewool", "White wool", {name: "whitewool", meta: 0}, {stack: 64});



IDRegistry.genItemID("graywool");
Item.createItem("graywool", "Gray wool", {name: "graywooll", meta: 0}, {stack: 64});






IDRegistry.genItemID("blackflint");
Item.createItem("blackflint", "Black flint", {name: "blackflint", meta: 0}, {stack: 64});


IDRegistry.genItemID("redflint");
Item.createItem("redflint", "Red flint", {name: "redflint", meta: 0}, {stack: 64});






IDRegistry.genItemID("blackingot");
Item.createItem("blackingot", "Black ingot", {name: "blackingot", meta: 0}, {stack: 64});


IDRegistry.genItemID("redingot");
Item.createItem("redingot", "Red ingot", {name: "redingot", meta: 0}, {stack: 64});


IDRegistry.genItemID("yellowingot");
Item.createItem("yellowingot", "Yellow ingot", {name: "yellowingot", meta: 0}, {stack: 64});


IDRegistry.genItemID("greeningot");
Item.createItem("greeningot", "Green ingot", {name: "greeningot", meta: 0}, {stack: 64});


IDRegistry.genItemID("arkeniumingotsh");
Item.createItem("arkeniumingotsh", "Arkenium ingot", {name: "arkeniumingotsh", meta: 0}, {stack: 64});







IDRegistry.genItemID("blackleather");
Item.createItem("blackleather", "Black leather", {name: "blackleather", meta: 0}, {stack: 64});



IDRegistry.genItemID("blackleather");
Item.createItem("blackleather", "Black leather", {name: "blackleather", meta: 0}, {stack: 64});


IDRegistry.genItemID("greenleather");
Item.createItem("greenleather", "Green leather", {name: "greenleather", meta: 0}, {stack: 64});


IDRegistry.genItemID("redleather");
Item.createItem("redleather", "Red leather", {name: "redleather", meta: 0}, {stack: 64});



IDRegistry.genItemID("yellowleather");
Item.createItem("yellowleather", "Yellow leather", {name: "yellowleatherr", meta: 0}, {stack: 64});

IDRegistry.genItemID("blueleather");
Item.createItem("blueleather", "Blue leather", {name: "blueleatherr", meta: 0}, {stack: 64});

IDRegistry.genItemID("purpleleather");
Item.createItem("purpleleather", "Purple leather", {name: "purpleleather", meta: 0}, {stack: 64});






IDRegistry.genItemID("captainstar");
Item.createItem("captainstar", "Captain America star", {name: "captainstar", meta: 0}, {stack: 64});


IDRegistry.genItemID("generator");
Item.createItem("generator", "Generator", {name: "generator", meta: 0}, {stack: 64});




IDRegistry.genItemID("greenarrow");
Item.createItem("greenarrow", "Green arrow", {name: "greenarrow", meta: 0}, {stack: 64});


IDRegistry.genItemID("ironstick");
Item.createItem("ironstick", "Iron stick", {name: "ironstick", meta: 0}, {stack: 64});


IDRegistry.genItemID("krypton");
Item.createItem("krypton", "Kryptonite", {name: "krypton", meta: 0}, {stack: 64});


IDRegistry.genItemID("vibranium");
Item.createItem("vibranium", "Vibranium", {name: "vibranium", meta: 0}, {stack: 64});


IDRegistry.genItemID("raccoonwool");
Item.createItem("raccoonwool", "Raccoon fur", {name: "raccoonwool", meta: 0}, {stack: 64});








